#include <iostream>
#include <array>

#include "../include/mouse/mouse.h"


int main() {
	rwa2::Mouse mouse;
	mouse.display_walls();

}

