var searchData=
[
  ['compute_5fnumber_5fof_5fwalls',['compute_number_of_walls',['../classrwa2_1_1_node.html#a6057b0b97f6b815a57aad534cd021674',1,'rwa2::Node']]]
];
