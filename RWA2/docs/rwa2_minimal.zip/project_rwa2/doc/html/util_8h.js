var util_8h =
[
    [ "direction", "util_8h.html#a99f26e6ee9fcd62f75203b5402df8098", [
      [ "NORTH", "util_8h.html#a99f26e6ee9fcd62f75203b5402df8098ad0611de6f28d4a9c9eac959f5344698e", null ],
      [ "EAST", "util_8h.html#a99f26e6ee9fcd62f75203b5402df8098ab5b3793b961949c817c7c0d99c05dad7", null ],
      [ "SOUTH", "util_8h.html#a99f26e6ee9fcd62f75203b5402df8098a8ef5c0bce69283a9986011a63eea8a6b", null ],
      [ "WEST", "util_8h.html#a99f26e6ee9fcd62f75203b5402df8098ae9449e8683a8199dad36b07a63b2f523", null ]
    ] ]
];